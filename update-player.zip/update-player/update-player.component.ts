import { Component, OnInit } from '@angular/core';
import { CricketService } from '../cricket.service';
import { Player } from '../player';

@Component({
  selector: 'app-update-player',
  templateUrl: './update-player.component.html',
  styleUrls: ['./update-player.component.scss']
})
export class UpdatePlayerComponent implements OnInit {
  flag: boolean = false;
  flag2: boolean = false;
  players: Player[] = [];
  player: Player;
  player2: Player;
  constructor(private service: CricketService) { }



  ngOnInit() {
    this.getAllPlayers();

  }
  getAllPlayers() {
    this.service.getPlayers().subscribe((res: any) => {
      this.players = res.data;
      console.log("data displayed");
    }, err => {
      console.log("error..pls check");
    })

  }

  printDetails(plr) {
    this.flag = true;
    this.player = plr;
  }

  editPlayer(player1) {
    this.flag2 = true;
    this.player2 = player1;
  }

  updatePlayer() {
    this.service.updatePlayer(this.player2).subscribe((res: any) => {
      console.log(res);
      alert(' updated successfully');
    }, err => {
      console.log(err);
      alert('player creation failed try again...');
    })
  }
}
