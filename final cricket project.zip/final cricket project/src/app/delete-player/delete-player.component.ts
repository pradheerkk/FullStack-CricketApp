import { Component, OnInit } from '@angular/core';
import { CricketService } from '../cricket.service';
import { Player } from '../player';

@Component({
  selector: 'app-delete-player',
  templateUrl: './delete-player.component.html',
  styleUrls: ['./delete-player.component.scss']
})
export class DeletePlayerComponent implements OnInit {
    sid:number;
    players:Player[]=[];
  constructor(private service:CricketService) { }

  ngOnInit() {
 // this.deleteAllPlayer();
 this.getAllPlayers();
  }
  getAllPlayers(){
    this.service.getPlayers().subscribe((res:any)=>{
      this.players=res.data;
      console.log("data displayed");
    },err =>{
      console.log("error..pls check");
    })

  }
  deleteAllPlayer(id1){
    this.sid=id1;
    this.service.deletePlayer(this.sid).subscribe((res:any)=>{
      //this.player=res.data;
      console.log(res);
      alert("player deleted");
    },err =>{
     console.log(err);
   })

  }
}
