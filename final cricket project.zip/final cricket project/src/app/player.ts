export class Player {
    id: number;
    name: string;
    country: string;
    category: string;
    image: string;
    createdAt: string;
    updatedAt: string;
}
