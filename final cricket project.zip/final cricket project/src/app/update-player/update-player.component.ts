import { Component, OnInit } from '@angular/core';
import { CricketService } from '../cricket.service';
import { Player } from '../player';

@Component({
  selector: 'app-update-player',
  templateUrl: './update-player.component.html',
  styleUrls: ['./update-player.component.scss']
})
export class UpdatePlayerComponent implements OnInit {
  flag: boolean = false;
  flag2: boolean = false;
  flag3:boolean =true;
  players: Player[] = [];
  player: Player;
  player2: Player;
  constructor(private service: CricketService) { }



  ngOnInit() {
    this.getAllPlayers();

  }
  getAllPlayers() {
    this.service.getPlayers().subscribe((res: any) => {
      this.players = res.data;
      console.log("data displayed");
    }, err => {
      console.log("error..pls check");
    })

  }

  printDetails(plr) {
    this.flag = true;
    this.player = plr;
    this.flag3=false;
  }

  editPlayer(player1) {
    this.flag2 = true;
    this.player2 = player1;
    this.flag=false;
  }

  updatePlayer() {
    this.service.updatePlayer(this.player2).subscribe((res: any) => {
      console.log(res);
      alert(' updated successfully');
      this.flag3=true;
      this.flag2=false;
    }, err => {
      console.log(err);
    
      alert('player creation failed try again...');
      this.flag3=true;
      this.flag2=false;
    })
  }
}
