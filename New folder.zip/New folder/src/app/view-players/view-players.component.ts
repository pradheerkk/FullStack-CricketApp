import { Component, OnInit } from '@angular/core';
import { CricketService } from '../cricket.service';
import { Player } from '../player';

@Component({
  selector: 'app-view-players',
  templateUrl: './view-players.component.html',
  styleUrls: ['./view-players.component.scss']
})
export class ViewPlayersComponent implements OnInit {
  //condition=false;
  players : Player[]=[];
  constructor(private service:CricketService ){}

  ngOnInit() {
    this.getAllPlayers();
  }

  getAllPlayers(){
    this.service.getPlayers().subscribe((res:any)=>{
      this.players=res.data;
      console.log("data displayed");
    },err =>{
      console.log("error..pls check");
    })

  }
}