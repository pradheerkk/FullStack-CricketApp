import { Component, OnInit } from '@angular/core';
import{Player} from '../player';
import {CricketService} from '../cricket.service';
@Component({
  selector: 'app-view-player',
  templateUrl: './view-player.component.html',
  styleUrls: ['./view-player.component.scss']
})
export class ViewPlayerComponent implements OnInit {
  players : Player[]=[];
  constructor(private service:CricketService ){}

  ngOnInit() {
    this.getAllPlayers();
  }

  getAllPlayers(){
    this.service.getPlayers().subscribe((res:any)=>{
      this.players=res.data;
      console.log("data displayed");
    },err =>{
      console.log("error..pls check");
    })

  }
}
